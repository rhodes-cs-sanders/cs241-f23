package squareworld.actor;

import squareworld.Board;
import squareworld.Location;
import squareworld.BoardUpdatePolicy;

import java.util.ArrayList;

public class ActorUpdatePolicy implements BoardUpdatePolicy<Actor> {
    @Override
    public Board<Actor> updateBoard(Board<Actor> board) {
        ArrayList<Actor> actors = new ArrayList<>();
        for (Location loc : board.getOccupiedLocations())
            actors.add(board.get(loc));

        for (Actor act : actors) {
            // only act if another actor hasn't removed us
            if (act.getBoard() == board)
                act.act();
        }
        return board;
    }
}
