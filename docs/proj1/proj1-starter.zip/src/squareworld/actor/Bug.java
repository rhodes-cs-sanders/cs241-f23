package squareworld.actor;

import squareworld.*;

/**
 * A <code>Bug</code> is an actor that can move and turn. It drops flowers as
 * it moves. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class Bug extends Actor
{
    /**
     * A Bug will try to walk forward if it can, otherwise it will turn right.
     */
    public void act()
    {
        if (canMoveForward())
            moveForward();
        else
            turnRight();
    }

    /**
     * Turns the bug 90 degrees to the right without changing its location.
     */
    public void turnRight()
    {
        // Get the current direction that we are facing.
        Direction myDirection = getDirection();

        // Compute the new direction, which is 90 degrees clockwise.
        Direction newDirection = myDirection.rotateClockwise(90);

        // Set our new direction.
        setDirection(newDirection);
    }

    /**
     * Moves the bug forward, putting a flower into the location it previously
     * occupied.
     */
    public void moveForward()
    {
        // Check if we are currently on the board.
        Board<Actor> board = getBoard();
        if (board == null)
            return;

        // Get our current location and the direction we are facing.
        Location myLocation = getLocation();
        Direction myDirection = getDirection();

        // Compute the location of the adjacent square we are facing towards.
        Location locationFacing = myLocation.getAdjacentLocation(myDirection);

        // If it's a valid square (not off the board), move into it, overwriting
        // any actor that is already there.  If it's invalid, then we're about to
        // walk off the board, so remove ourselves.
        if (board.isValid(locationFacing))
            moveTo(locationFacing);
        else
            removeSelfFromBoard();

        // Drop a flower in our previous location.
        Flower flower = new Flower();
        flower.addSelfToBoard(board, myLocation);
    }

    /**
     * Tests whether this bug can move forward into a location that is empty or
     * contains a flower.
     * @return true if this bug can move forward.
     */
    public boolean canMoveForward()
    {
        // Check if we are currently on the board.
        Board<Actor> board = getBoard();
        if (board == null)
            return false;

        // Get our current location and the direction we are facing.
        Location myLocation = getLocation();
        Direction myDirection = getDirection();

        // Compute the location of the adjacent square we are facing towards.
        Location locationFacing = myLocation.getAdjacentLocation(myDirection);

        // If the square we're facing is not valid (if it's off the board), return false,
        // indicating we can't move forward.
        if (!board.isValid(locationFacing))
            return false;

        // Get the actor in the square we're facing.
        Actor neighbor = board.get(locationFacing);

        // It's ok to move onto an empty square (null) or a Flower,
        // so return true in those cases, false otherwise.
        return (neighbor == null) || (neighbor instanceof Flower);
    }
}
