package squareworld.actor;

import squareworld.*;

/**
 * An <code>Actor</code> is an entity with a color and direction that can act.
 * <br />
 */
public abstract class Actor implements BoardObject, Orientable {
    private Board<Actor> board;     // the board on which this actor lives.
    private Location location;      // the location of the actor on the board.
    private Direction direction;    // the direction the actor is facing.

    /**
     * Constructs an actor that is facing north.
     */
    public Actor() {
        direction = Direction.NORTH;
        board = null;
        location = null;
    }

    /**
     * Gets the current direction of this actor.
     *
     * @return the direction of this actor, an angle between 0 and 359 degrees
     */
    public Direction getDirection() {
        return direction;
    }

    /**
     * Sets the current direction of this actor.
     *
     * @param newDirection the new direction. The direction of this actor is set
     *                     to the angle between 0 and 359 degrees that is equivalent to
     *                     <code>newDirection</code>.
     */
    public void setDirection(Direction newDirection) {
        direction = newDirection;
    }

    /**
     * Gets the grid in which this actor is located.
     *
     * @return the grid of this actor, or <code>null</code> if this actor is
     * not contained in a grid
     */
    public Board<Actor> getBoard() {
        return board;
    }

    /**
     * Gets the location of this actor.
     *
     * @return the location of this actor, or <code>null</code> if this actor is
     * not contained in a grid
     */
    public Location getLocation() {
        return location;
    }

    /**
     * Puts this actor into a grid. If there is another actor at the given
     * location, it is removed. <br />
     * Precondition: (1) This actor is not contained in a grid (2)
     * <code>loc</code> is valid in <code>gr</code>
     *
     * @param board the grid into which this actor should be placed
     * @param loc   the location into which the actor should be placed
     */
    public void addSelfToBoard(Board<Actor> board, Location loc) {
        if (this.board != null)
            throw new IllegalStateException(
                    "This actor is already contained in a grid.");

        Actor actor = board.get(loc);
        if (actor != null)
            actor.removeSelfFromBoard();
        board.put(loc, this);
        this.board = board;
        location = loc;
    }

    /**
     * Removes this actor from its grid. <br />
     * Precondition: This actor is contained in a grid
     */
    public void removeSelfFromBoard() {
        if (board == null)
            throw new IllegalStateException(
                    "This actor is not contained in a grid.");
        if (board.get(location) != this)
            throw new IllegalStateException(
                    "The grid contains a different actor at location "
                            + location + ".");

        board.remove(location);
        board = null;
        location = null;
    }

    /**
     * Moves this actor to a new location. If there is another actor at the
     * given location, it is removed. <br />
     * Precondition: (1) This actor is contained in a grid (2)
     * <code>newLocation</code> is valid in the grid of this actor
     *
     * @param newLocation the new location
     */
    public void moveTo(Location newLocation) {
        if (board == null)
            throw new IllegalStateException("This actor is not in a grid.");
        if (board.get(location) != this)
            throw new IllegalStateException(
                    "The grid contains a different actor at location "
                            + location + ".");
        if (!board.isValid(newLocation))
            throw new IllegalArgumentException("Location " + newLocation
                    + " is not valid.");

        if (newLocation.equals(location))
            return;
        board.remove(location);
        Actor other = board.get(newLocation);
        if (other != null)
            other.removeSelfFromBoard();
        location = newLocation;
        board.put(location, this);
    }

    /**
     * Override this method in subclasses
     * of <code>Actor</code> to define types of actors with different behavior
     */
    public abstract void act();

    /**
     * Creates a string that describes this actor.
     *
     * @return a string with the location, direction, and color of this actor
     */
    public String toString() {
        return getClass().getName() + "[location=" + location + ",direction="
                + direction + "]";
    }

    @Override
    public char getBoardChar() {
        return 'A';
    }
}