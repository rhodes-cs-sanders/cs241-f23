package squareworld.actor;

import squareworld.Direction;
import squareworld.actor.Flower;

/**
 * A FancyFlower is a Flower where the user can control
 * how quickly it rotates, and it also switches rotation direction.
 */
public class FancyFlower extends Flower
{
    private boolean rotatingClockwise;      // are we rotating clockwise or counter-clockwise?
    private final int degreesPerRotation;   // how much do we rotate per call to act()?

    /**
     * Construct a new FancyFlower, given the number of degrees it rotates each timestep.
     */
    public FancyFlower(int degreesPerRotation)
    {
        this.degreesPerRotation = degreesPerRotation;
        rotatingClockwise = true;
    }

    /**
     * Rotate the flower by the specified degrees, and switch directions
     * if we reach zero degrees.
     */
    @Override
    public void act()
    {
        // Get the current direction that we are facing.
        Direction myDirection = getDirection();

        // Compute the new direction.
        Direction newDirection;
        if (rotatingClockwise)
            newDirection = myDirection.rotateClockwise(degreesPerRotation);
        else
            newDirection = myDirection.rotateCounterClockwise(degreesPerRotation);

        // Turn the flower to our new direction.
        setDirection(newDirection);

        // If we reach zero degrees, switch direction (for the next time act() is called).
        if (getDirection().getDegrees() == 0)  // myDirection is the old direction, so it's no good anymore
        {
            rotatingClockwise = !rotatingClockwise;
        }
    }
}
