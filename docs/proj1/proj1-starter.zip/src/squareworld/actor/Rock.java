package squareworld.actor;

import squareworld.Direction;
import squareworld.Location;

/**
 * A <code>Rock</code> is an Actor that does nothing. It is commonly used to
 * block other actors from moving. <br />
 */

public class Rock extends Actor
{
    @Override
    public void act() {
        // Literally do nothing.  A rock just sits there.

        // The lines below are for demonstration/debug purposes.  Remove them when you start
        // implementing the project.
        Location loc = getLocation();
        System.out.println("I am a rock at location " + loc);

    }
}
