package squareworld;

/**
 * A Direction stores one of the 8 main compass directions.
 */
public enum Direction {
    NORTH(-1, 0, 0),
    NORTHEAST(-1, 1, 45),
    EAST(0, 1, 90),
    SOUTHEAST(1, 1, 135),
    SOUTH(1, 0, 180),
    SOUTHWEST(1, -1, 225),
    WEST(0, -1, 270),
    NORTHWEST(-1, -1, 315);

    final private int rowChange, colChange, degrees;

    /**
     * Create a new direction directly.  (Users should call fromDegrees instead)
     */
    Direction(int rowChange, int colChange, int degrees)
    {
        this.rowChange = rowChange;
        this.colChange = colChange;
        this.degrees = degrees;
    }

    /**
     * Create a direction from a number of degrees, that will be rounded to the nearest
     * of the eight main directions.
     */
    public static Direction fromDegrees(int degrees)
    {
        // make degrees between 0 and 359.
        if (degrees < 0) degrees += 360;
        if (degrees < 0) degrees += 360;
        if (degrees >= 360) degrees -= 360;
        if (degrees >= 360) degrees -= 360;

        if ((degrees > 0-22.5 && degrees < 0+22.5) || (degrees > 360-22.5 && degrees < 360+22.5))
            return NORTH;
        else if (degrees > 90-22.5 && degrees < 90+22.5)
            return EAST;
        else if (degrees > 180-22.5 && degrees < 180+22.5)
            return SOUTH;
        else if (degrees > 270-22.5 && degrees < 270+22.5)
            return WEST;
        else if (degrees > 45-22.5 && degrees < 45+22.5)
            return NORTHEAST;
        else if (degrees > 135-22.5 && degrees < 135+22.5)
            return SOUTHEAST;
        else if (degrees > 225-22.5 && degrees < 225+22.5)
            return SOUTHWEST;
        else if (degrees > 315-22.5 && degrees < 315+22.5)
            return NORTHWEST;
        else
            throw new IllegalArgumentException("accident");  // should never happen
    }

    /** Create a direction by rotating an existing direction a certain number of degrees clockwise.
     */
    public Direction rotateClockwise(int degrees)
    {
        return Direction.fromDegrees(getDegrees() + degrees);
    }

    /** Create a direction by rotating an existing direction a certain number of degrees counter-clockwise.
     */
    public Direction rotateCounterClockwise(int degrees)
    {
        return Direction.fromDegrees(getDegrees() - degrees);
    }

    /**
     * Get the row difference for this direction, if someone were to take a single step.
     * e.g., for NORTH, NORTHEAST, NORTHWEST, this difference is -1, and for
     * SOUTH, SOUTHEAST, and SOUTHWEST, it is +1.
     */
    public int getRowDifference() {
        return rowChange;
    }

    /**
     * Get the column difference for this direction, if someone were to take a single step.
     * e.g., for EAST, NORTHEAST, SOUTHEAST, this difference is +1, and for
     * WEST, NORTHWEST, and SOUTHWEST, it is -1.
     */
    public int getColDifference() {
        return colChange;
    }

    /**
     * Return this direction as a number of degrees between 0 and 359.
     */
    public int getDegrees() { return degrees; }
}
