package squareworld;


/**
 * BoardObjects may be stored in Boards.  This interface exists only
 * to support Boards being drawn in a text interface.
 */
public interface BoardObject {

    /**
     * Return the single character that should be used to represent this BoardObject
     * in text-based output.
     */
    public char getBoardChar();
}
