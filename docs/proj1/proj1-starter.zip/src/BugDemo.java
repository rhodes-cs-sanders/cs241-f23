import squareworld.Board;
import squareworld.BoardManager;
import squareworld.Location;
import squareworld.actor.*;

/**
 * This class demonstrates the Bug, Rock, and Flower classes, all of which are Actors.
 *
 */
public class BugDemo
{
    public static void main(String[] args)
    {
        Board<Actor> board = new Board<Actor>(10, 10);

        Flower f1 = new Flower();
        Flower f2 = new Flower();
        Rock r1 = new Rock();
        Rock r2 = new Rock();
        Rock r3 = new Rock();
        Bug b = new Bug();

        f1.addSelfToBoard(board, new Location(1, 2));
        f2.addSelfToBoard(board, new Location(8, 7));
        r1.addSelfToBoard(board, new Location(4, 4));
        r2.addSelfToBoard(board, new Location(5, 8));
        r3.addSelfToBoard(board, new Location(9, 2));
        b.addSelfToBoard(board, new Location(7, 4));

        BoardManager<Actor> manager = new BoardManager<Actor>(board, new ActorUpdatePolicy());
        manager.display();
    }
}
