import squareworld.Board;
import squareworld.BoardManager;
import squareworld.Location;
import squareworld.actor.*;

import java.io.InputStream;
import java.util.Scanner;

public class MazeWorld {

    public static void main(String[] args)
    {
        System.out.print("What maze file do you want to read? ");
        Scanner scan = new Scanner(System.in);
        String filename = scan.nextLine();

        Board<Actor> board = loadBoard(filename);

        ActorUpdatePolicy policy = new ActorUpdatePolicy();
        BoardManager<Actor> boardManager = new BoardManager<Actor>(board, policy);
        boardManager.display();
    }

    /**
     * Load a board of actors from a file.
     */
    public static Board<Actor> loadBoard(String filename)
    {
        Board<Actor> board;
        InputStream is = MazeWorld.class.getResourceAsStream(filename);
        if (is == null) {
            System.err.println("Bad filename: " + filename);
            System.exit(1);
        }
        Scanner scan = new Scanner(is);
        int rows = scan.nextInt();  // read first integer in file
        int cols = scan.nextInt();  // read second integer in file
        scan.nextLine(); // move reader to start of board characters

        // Create the board.
        board = new Board<Actor>(rows, cols);

        int row = 0;  // keep track of the row we're reading
        while (scan.hasNextLine())
        {
            String line = scan.nextLine();
            System.out.println("line = " + line);
            for (int col = 0; col < line.length(); col++)
            {
                char ch = line.charAt(col);
                if (ch == 'R')
                {
                    // Create a Rock and call addSelfToBoard.
                }
                else if (ch == 'F')
                {
                    // Create a Flower and call addSelfToBoard.
                }
                else if (ch == 'M')
                {
                    // Create a Mouse and call addSelfToBoard.
                }
            }
            row++;
        }

        return board;
    }
}
