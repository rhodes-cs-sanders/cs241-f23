import squareworld.Board;
import squareworld.BoardManager;
import squareworld.Location;
import squareworld.actor.*;

import java.util.Scanner;

public class SquareBugDemo
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        System.out.print("How big should the square be? ");
        int size = scan.nextInt();

        Board<Actor> board = new Board<Actor>(20, 20);

        SquareBug bug = new SquareBug(size);
        bug.addSelfToBoard(board, new Location(15, 5));

        BoardManager<Actor> manager = new BoardManager<Actor>(board, new ActorUpdatePolicy());
        manager.display();
    }
}
