import squareworld.Board;
import squareworld.BoardManager;
import squareworld.Location;
import squareworld.actor.*;

/**
 * This class demonstrates the Rock and Flower classes, all of which are Actors.
 *
 */
public class RockAndFlowerDemo
{
    public static void main(String[] args)
    {
        Board<Actor> board = new Board<Actor>(5, 5);

        Flower f1 = new Flower();
        Flower f2 = new Flower();
        Rock r1 = new Rock();
        Rock r2 = new Rock();
        Rock r3 = new Rock();

        f1.addSelfToBoard(board, new Location(1, 4));
        f2.addSelfToBoard(board, new Location(4, 1));
        r1.addSelfToBoard(board, new Location(3, 3));
        r2.addSelfToBoard(board, new Location(2, 0));
        r3.addSelfToBoard(board, new Location(0, 2));

        BoardManager<Actor> manager = new BoardManager<Actor>(board, new ActorUpdatePolicy());
        manager.display();
    }
}
